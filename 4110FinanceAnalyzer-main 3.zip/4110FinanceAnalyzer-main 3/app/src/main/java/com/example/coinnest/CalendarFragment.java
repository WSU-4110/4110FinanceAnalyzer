
/*Jordan's Code*/

package com.example.coinnest;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.time.LocalDate;
import java.util.Calendar;

public class CalendarFragment extends Fragment implements View.OnClickListener{

//    Button btnDatePicker;
//    TextView txtDate;
//    private int sYear, sMonth, sDay;

    private TextView monthYearText;
    private RecyclerView calendarRecyclerView;
    private LocalDate selectedDate;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_calendar, container, false);

//        btnDatePicker = (Button) view.findViewById(R.id.btn_pickdate);
//        txtDate = (TextView)view.findViewById(R.id.txtview_showdate);

//        btnDatePicker.setOnClickListener(this);

        return inflater.inflate(R.layout.fragment_calendar, container, false);
    }

    @Override
    public void onClick(View v) {

    }

    public void selectDate(View view)
    {
        Intent intent = new Intent(getActivity(), CalendarViewActivity.class);
        startActivity(intent);
    }
}
